# CARA MEMBUAT APK RENTAL DARI HP

Project ini sudah disiapkan agar APK bisa dibuild otomatis oleh GitHub Actions, tanpa Android Studio di HP.

## 1. Buat repository GitHub
- Buka GitHub dan login.
- Buat repository baru, misalnya `rental-live-v74`.
- Pilih Public atau Private sesuai kebutuhan.

## 2. Upload isi folder project
Upload **semua isi folder `RENTAL-APK-V74`** ke repository.
Pastikan file berikut ada di root repository:
- `settings.gradle`
- `build.gradle`
- `app/`
- `.github/workflows/build-apk.yml`

## 3. Jalankan build
Di repository GitHub:
- buka menu **Actions**
- pilih workflow **Build Rental APK**
- tekan **Run workflow**
- tunggu sampai selesai.

## 4. Ambil APK
Setelah selesai:
- buka hasil workflow tersebut
- cari bagian **Artifacts**
- download `Rental-Live-V74-APK`
- di dalam ZIP terdapat `app-debug.apk`
- install APK tersebut di HP Rental.

## Fungsi APK
- Tidak memakai Chrome.
- Tidak ada address bar, Home Chrome, tab, tombol +, atau menu browser.
- Rental hanya membaca Firebase master Index.
- Index adalah satu-satunya sumber timer dan nominal.
- Setelah memilih box, Rental hanya menampilkan BOX + TIMER + RUPIAH.
- Kontrol di layar Rental dinonaktifkan setelah box dipilih.
- Keluar dari aplikasi tetap memakai tombol/gesture Android sehingga aplikasi lain tetap bisa dipakai.

## Catatan
APK ini membutuhkan internet untuk membaca Firebase. Jangan mengubah `rental.html` jika tujuan Anda hanya ingin membuat APK; file tersebut adalah VIEW terhadap data Index.
