# Rental Live APK – V74

Aplikasi Android pembungkus untuk `rental.html`.

## Perilaku
- Tidak membuka Chrome dan tidak menampilkan address bar, Home, tab, +, atau menu browser.
- Rental tetap hanya VIEW terhadap Firebase master Index.
- Setelah memilih box, tampilan Rental hanya box + timer + rupiah.
- Tombol/klik di layar view tidak melakukan aksi.
- Keluar dari aplikasi memakai gesture/tombol navigasi Android atau tombol Back; aplikasi lain di HP tetap normal.
- Internet diperlukan karena Firebase dan library Firebase pada `rental.html` dimuat dari CDN.

## Build APK
Buka folder ini dengan Android Studio yang memiliki Android SDK/Build Tools. Pilih **Build > Build APK(s)**.

APK debug biasanya berada di:
`app/build/outputs/apk/debug/app-debug.apk`
